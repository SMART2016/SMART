/**
 */
package Example;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dog</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Example.ExamplePackage#getDog()
 * @model

 * @generated
 */
public interface Dog extends Pet {
} // Dog
