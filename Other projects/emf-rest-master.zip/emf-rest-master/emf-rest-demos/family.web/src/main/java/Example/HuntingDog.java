/**
 */
package Example;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hunting Dog</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Example.ExamplePackage#getHuntingDog()
 * @model

 * @generated
 */
public interface HuntingDog extends Dog {
} // HuntingDog
