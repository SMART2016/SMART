/**
 */
package Example;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Race Dog</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Example.ExamplePackage#getRaceDog()
 * @model

 * @generated
 */
public interface RaceDog extends Dog {
} // RaceDog
