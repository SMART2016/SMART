/**
 */
package Example;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cat</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Example.ExamplePackage#getCat()
 * @model

 * @generated
 */
public interface Cat extends Pet {
} // Cat
