website
=======

This are the source of the emf-rest project website, that you can find [here](http://emf-rest.com "EMF-REST").

The main repository of EMF-REST is [http://github.com/emf-rest/emf-rest](http://github.com/emf-rest/emf-rest "http://github.com/emf-rest/emf-rest")

This documentation is licensed under [CC BY 3.0](https://creativecommons.org/licenses/by/3.0 "CC BY 3.0").